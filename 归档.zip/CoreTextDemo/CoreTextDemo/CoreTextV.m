//
//  CoreTextV.m
//  CoreTextDemo
//
//  Created by Wicky on 16/4/22.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import "CoreTextV.h"
#import <CoreText/CoreText.h>
#import <UIKit/UIKit.h>

@interface CoreTextV ()
{
    CTFrameRef _frame;
    NSInteger _length;
    CGRect _imgFrm;
}
@end
@implementation CoreTextV
/*
 写在前面的总结
 coreText实现图文混排其实就是在富文本中插入一个空白的图片占位符的富文本字符串，通过代理设置相关的图片尺寸信息，根据从富文本得到的frame计算图片绘制的frame再绘制图片这么一个过程。网上之所以每个demo都那么冗长，实际上是因为他们先写了富文本的其他用法。
 */

-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
#pragma mark ---获取绘制上线文---
    CGContextRef context = UIGraphicsGetCurrentContext();
#pragma mark ---坐标系转换（flips）---
    /*
     coreText 起初是为OSX设计的，而OSX得坐标原点是左下角，y轴正方向朝上。iOS中坐标原点是左上角，y轴正方向向下。
     若不进行坐标转换，则文字从下开始，还是倒着的
     */
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);//设置字形的变换矩阵为不做图形变换
    CGContextTranslateCTM(context, 0, self.bounds.size.height);//将绘制区域向上平移屏幕高
    CGContextScaleCTM(context, 1.0, -1.0);//以画布x轴为轴旋转180度
    /*
     2.3句结合实现画布反转，固定写法
     */
#pragma mark ---图文混排---
    /*
     事实上，图文混排就是在要插入图片的位置插入一个富文本类型的占位符。通过CTRUNDelegate设置图片
     */
    NSMutableAttributedString * attributeStr = [[NSMutableAttributedString alloc] initWithString:@"\n这里在测试图文混排，\n我是一个富文本"];
    /*
     设置一个回调结构体，告诉代理该回调那些方法
     */
    CTRunDelegateCallbacks callBacks;//创建一个回调结构体，设置相关参数
    memset(&callBacks, 0, sizeof(CTRunDelegateCallbacks));//memset将已开辟内存空间 callbacks 的首 n 个字节的值设为值 0, 相当于对CTRunDelegateCallbacks内存空间初始化
    callBacks.version = kCTRunDelegateVersion1;//设置回调版本，默认这个
    callBacks.getAscent = ascentCallBacks;//设置图片顶部距离基线的距离
    callBacks.getDescent = descentCallBacks;//设置图片底部距离基线的距离
    callBacks.getWidth = widthCallBacks;//设置图片宽度
    
    /*
     创建一个代理
     */
    NSDictionary * dicPic = @{@"height":@129,@"width":@400};//创建一个图片尺寸的字典，初始化代理对象需要
    CTRunDelegateRef delegate = CTRunDelegateCreate(& callBacks, (__bridge void *)dicPic);//创建代理
    
    /*
     创建图片占位符
     */
    unichar placeHolder = 0xFFFC;//创建空白字符
    NSString * placeHolderStr = [NSString stringWithCharacters:&placeHolder length:1];//已空白字符生成字符串
    NSMutableAttributedString * placeHolderAttrStr = [[NSMutableAttributedString alloc] initWithString:placeHolderStr];//用字符串初始化占位符的富文本
    CFAttributedStringSetAttribute((CFMutableAttributedStringRef)placeHolderAttrStr, CFRangeMake(0, 1), kCTRunDelegateAttributeName, delegate);//给字符串中的范围中字符串设置代理
    CFRelease(delegate);//释放（__bridge进行C与OC数据类型的转换，C为非ARC，需要手动管理）
//    [placeHolderAttrStr addAttribute:@"imageName" value:@"bd_logo1.png" range:NSMakeRange(0, 1)];//上下两种写法等价，给占位符附图片,可选操作，可从富文本中读出图片信息，然而图片绘制与本句无关
    [attributeStr insertAttributedString:placeHolderAttrStr atIndex:12];//将占位符插入原富文本
    /*
     至此，带有图片的富文本已经制作完成
     */
    
#pragma mark ---设置frame---
    /*
     根据富文本生成frame
     */
    CTFramesetterRef frameSetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)attributeStr);//一个frame的工厂，负责生成frame
    CGMutablePathRef path = CGPathCreateMutable();//创建绘制区域
    CGPathAddRect(path, NULL, CGRectMake(0, -100, 414, 736));//添加绘制尺寸
    _length = attributeStr.length;
    _frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(0, _length), path, NULL);//工厂根据绘制区域及富文本（可选范围，多次设置）设置frame
    CTFrameDraw(_frame, context);//根据frame绘制上下文
#pragma mark ---绘制图片---
    UIImage * image = [UIImage imageNamed:@"bd_logo1"];
    _imgFrm = [[self calculateImageRectWithFrame:_frame].firstObject CGRectValue];
    CGContextDrawImage(context,_imgFrm, image.CGImage);//绘制图片
#pragma mark ---内存管理---
//    CFRelease(_frame);//偷懒下面直接用，所以不能释放
    CFRelease(path);
    CFRelease(frameSetter);
}
#pragma mark ---CTRUN代理---
static CGFloat ascentCallBacks(void * ref)
{
    return [(NSNumber *)[(__bridge NSDictionary *)ref valueForKey:@"height"] floatValue];
}
static CGFloat descentCallBacks(void * ref)
{
    return 0;
}
static CGFloat widthCallBacks(void * ref)
{
    return [(NSNumber *)[(__bridge NSDictionary *)ref valueForKey:@"width"] floatValue];
}

#pragma mark ---根据frame返回图片绘制的区域---
/*
 复用性高，抽出方法
 */
-(NSMutableArray *)calculateImageRectWithFrame:(CTFrameRef)frame
{
    NSArray * arrLines = (NSArray *)CTFrameGetLines(frame);//根据frame获取需要绘制的线的数组
    NSInteger count = [arrLines count];//获取线的数量
    CGPoint points[count];//建立起点的数组（cgpoint类型为结构体，故用C语言的数组）
    CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), points);//获取起点
    NSMutableArray * arr = [NSMutableArray array];
    for (int i = 0; i < count; i ++) {//遍历线的数组
        CTLineRef line = (__bridge CTLineRef)arrLines[i];
        NSArray * arrGlyphRun = (NSArray *)CTLineGetGlyphRuns(line);//获取GlyphRun数组（GlyphRun：高效的字符绘制方案）
        for (int j = 0; j < arrGlyphRun.count; j ++) {//遍历CTRun数组
            CTRunRef run = (__bridge CTRunRef)arrGlyphRun[j];//获取CTRun
            NSDictionary * attributes = (NSDictionary *)CTRunGetAttributes(run);//获取CTRun的属性
            CTRunDelegateRef delegate = (__bridge CTRunDelegateRef)[attributes valueForKey:(id)kCTRunDelegateAttributeName];//获取代理
            if (delegate == nil) {//非空
                continue;
            }
            NSDictionary * metaDic = CTRunDelegateGetRefCon(delegate);//判断代理字典
            if (![metaDic isKindOfClass:[NSDictionary class]]) {
                continue;
            }
            CGPoint point = points[i];//获取一个起点
            CGFloat ascent;//获取上距
            CGFloat descent;//获取下距
            CGRect boundsRun;//创建一个frame
            boundsRun.size.width = CTRunGetTypographicBounds(run, CFRangeMake(0, 0), &ascent, &descent, NULL);
            boundsRun.size.height = ascent + descent;
            CGFloat xOffset = CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL);//获取x偏移量
            boundsRun.origin.x = point.x + xOffset;//point是行起点位置，加上每个字的偏移量得到每个字的x
            boundsRun.origin.y = point.y - descent;
            CGPathRef path = CTFrameGetPath(frame);//获取绘制区域
            CGRect colRect = CGPathGetBoundingBox(path);//获取剪裁区域边框
            NSLog(@"%@",NSStringFromCGRect(colRect));
            CGRect deleteBounds = CGRectOffset(boundsRun, colRect.origin.x, colRect.origin.y);//获取绘制区域
            NSValue * value = [NSValue valueWithCGRect:deleteBounds];
            [arr addObject:value];
        }
    }
    return arr;
}
/*
 coreText获取点击事件
 思路：
 通过touch事件获取到点击屏幕上的点，转换成系统坐标，与CTV中的每个字符的frame作比较
 注意：
 要注意屏幕坐标与系统坐标的转换（屏幕坐标左上角原点，系统坐标左下角原点）
 方法：
 1.遍历富文本所有字符，比较每一个字符与点击的坐标，从而获取点击的字符，添加字符。适用于CTV中所有字符和图片
 2.因为绘制图片的时候有拿到图片的frame，故若只有图片想要获取事件则比较图片frame及点击做的即可。
 */
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    CGPoint location = [touch locationInView:self];
    CGRect newFrmToScreen = CGRectMake(_imgFrm.origin.x, self.bounds.size.height - _imgFrm.origin.y - _imgFrm.size.height, _imgFrm.size.width, _imgFrm.size.height);
    if ((location.x >= newFrmToScreen.origin.x) && (location.x <= newFrmToScreen.origin.x + newFrmToScreen.size.width) && (location.y >= newFrmToScreen.origin.y) && (location.y <= newFrmToScreen.origin.y + newFrmToScreen.size.height)) {
        NSLog(@"你点击了图片");
        return ;
    }
    CGPoint locToCT = CGPointMake(location.x, self.bounds.size.height - location.y);//坐标转换，把屏幕坐标转换成系统坐标
    NSArray * lines = (NSArray *)CTFrameGetLines(_frame);//获取所有CTLine
    CFRange ranges[lines.count];//初始化范围数组
    CGPoint origins[lines.count];//初始化原点数组
    CTFrameGetLineOrigins(_frame, CFRangeMake(0, 0), origins);//获取所有CTLine的原点
    for (int i = 0; i < lines.count; i ++) {
        CTLineRef line = (__bridge CTLineRef)lines[i];
        CFRange range = CTLineGetStringRange(line);
        ranges[i] = range;
    }//获取所有CTLine的Range
    for (int i = 0; i < _length; i ++) {//逐字检查
        long maxLoc;
        int lineNum;
        for (int j = 0; j < lines.count; j ++) {//获取对应字符所在CTLine的index
            CFRange range = ranges[j];
            maxLoc = range.location + range.length - 1;
            if (i <= maxLoc) {
                lineNum = j;
                break;
            }
        }
        CTLineRef line = (__bridge CTLineRef)lines[lineNum];//取到字符对应的CTLine
        CGPoint origin = origins[lineNum];//取到CTLine原点
        CGFloat offsetX = CTLineGetOffsetForStringIndex(line, i, NULL);//获取字符起点相对于CTLine的原点的偏移量
        CGFloat offsexX2 = CTLineGetOffsetForStringIndex(line, i + 1, NULL);//获取下一个字符的偏移量，两者之间即为字符X范围
        offsetX += origin.x;
        offsexX2 += origin.x;//坐标转换，将点的CTLine坐标转换至系统坐标
        CGFloat offsetY = origin.y;//取到CTLine的起点Y
        CGFloat offsetY2;
        CGFloat lineAscent;
        CGFloat lineDescent;//初始化上下边距的变量
        NSArray * runs = (__bridge NSArray *)CTLineGetGlyphRuns(line);//获取所有CTRun
        CTRunRef runCurrent;
        for (int k = 0; k < runs.count; k ++) {//获取当前点击的CTRun
            CTRunRef run = (__bridge CTRunRef)runs[k];
            CFRange range = CTRunGetStringRange(run);
            if ((i >= range.location) && (i <=range.location + range.length - 1)) {
                runCurrent = run;
                break;
            }
        }
        CTRunGetTypographicBounds(runCurrent, CFRangeMake(0, 0), &lineAscent, &lineDescent, NULL);//计算当前点击的CTRun高度
        CGFloat height = lineAscent + lineDescent;
        CGPathRef path = CTFrameGetPath(_frame);
        CGRect colRect = CGPathGetBoundingBox(path);
        offsetX += colRect.origin.x;
        offsexX2 += colRect.origin.x;
        offsetY2 = offsetY + height;
        offsetY += colRect.origin.y;
        offsetY2 += colRect.origin.y;
        if ((locToCT.x >= offsetX)&&(locToCT.x <= offsexX2)&&(locToCT.y >= offsetY)&& (locToCT.y <= offsetY2)) {//如果点击位置在X、Y范围内，响应时间，跳出循环
            NSLog(@"%d",i);
            break;
        }
    }
}
@end
