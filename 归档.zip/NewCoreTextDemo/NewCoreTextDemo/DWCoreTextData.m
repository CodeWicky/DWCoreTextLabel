//
//  DWCoreTextData.m
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import "DWCoreTextData.h"

@implementation DWCoreTextData
-(instancetype)initWithHeight:(CGFloat)height frame:(CTFrameRef)frame STRLength:(NSInteger)length
{
    self = [super init];
    if (self) {
        self.height = height;
        self.ctFrame = frame;
        self.length = length;
    }
    return self;
}
-(void)setCtFrame:(CTFrameRef)ctFrame
{
    if (_ctFrame != ctFrame) {
        if (_ctFrame != nil) {
            CFRelease(_ctFrame);
        }
        CFRetain(ctFrame);
        _ctFrame = ctFrame;
    }
}
-(void)dealloc
{
    if (_ctFrame != nil) {
        CFRelease(_ctFrame);
        _ctFrame = nil;
    }
}
@end
