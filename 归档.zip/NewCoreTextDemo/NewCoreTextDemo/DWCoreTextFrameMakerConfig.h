//
//  DWCoreTextFrameMakerConfig.h
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//


/*
 配置信息
 
 保存全文基本属性
 */
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface DWCoreTextFrameMakerConfig : NSObject
@property (assign ,nonatomic)CGFloat width;
@property (assign ,nonatomic)CGFloat fontSize;
@property (assign ,nonatomic)CGFloat lineSpace;
@property (strong ,nonatomic)UIColor * color;
@property (strong ,nonatomic)NSString * fontFamily;
///设置全文属性
-(instancetype)initWithWidth:(CGFloat)width
                    fontSize:(CGFloat)fontSize
                   lineSpace:(CGFloat)lineSpace
                       color:(UIColor *)color
                  fontFamily:(NSString *)fontFamily;
@end
