//
//  DWCoreTextFrameMaker.h
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//


/*
 CT制造者
 对富文本做任何操作，包括添加属性和图片
 并且通过已经生成好的富文本生成CT数据
 */
#import <Foundation/Foundation.h>
#import "DWCoreTextFrameMakerConfig.h"
#import "DWCoreTextData.h"
@interface DWCoreTextFrameMaker : NSObject
@property (strong ,nonatomic)NSMutableAttributedString * attributeSTR;
///以配置信息、文本初始化CT创建类
-(instancetype)initWithString:(NSString *)string
                       config:(DWCoreTextFrameMakerConfig *)config;
///根据配置信息返回CT数据
-(DWCoreTextData *)MakeCoreTextDataWithConfig:(DWCoreTextFrameMakerConfig *)config;
///给字符串添加局部属性
-(void)addAttribute:(NSString *)attributeName
              value:(id)value
              range:(NSRange)range;
///根据图片信息字典插入图片至富文本
-(void)insertPicWithDictionary:(NSMutableDictionary *)dic;
///根据装有多个图片信息字典的数据插入图片至富文本
-(void)insertPicWithArrayOfDictionarys:(NSMutableArray *)arr;
///根据图片信息返回相关信息的字典
-(NSMutableDictionary *)makePicDictionaryWithImageName:(NSString *)imgName
                                        InsertLocation:(NSInteger)loacation
                                             imageSize:(CGSize)size;
@end
