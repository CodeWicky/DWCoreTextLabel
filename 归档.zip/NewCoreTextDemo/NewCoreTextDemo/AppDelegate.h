//
//  AppDelegate.h
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

