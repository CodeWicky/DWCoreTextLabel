//
//  ViewController.m
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import "ViewController.h"
#import "DWCoreTextView.h"
@interface ViewController ()
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
#pragma mark ---DWCoreText使用基本流程---
#pragma mark ---1.创建一个基本属性类---
    DWCoreTextFrameMakerConfig * config = [[DWCoreTextFrameMakerConfig alloc] initWithWidth:self.view.bounds.size.width fontSize:20 lineSpace:8 color:[UIColor blackColor] fontFamily:@"ArialMT"];
    NSString *content =
    @"对于上面的例子，我们给 CTFrameParser 增加了一个将 NSString 转 "
    " 换为 CoreTextData 的方法。"
    " 但这样的实现方式有很多局限性，因为整个内容虽然可以定制字体 "
    " 大小，颜色，行高等信息，但是却不能支持定制内容中的某一部分。"
    " 例如，如果我们只想让内容的前三个字显示成红色，而其它文字显 "
    " 示成黑色，那么就办不到了。"
    "\n\n"
    " 解决的办法很简单，我们让`CTFrameParser`支持接受 "
    "NSAttributeString 作为参数，然后在 NSAttributeString 中设置好 "
    " 我们想要的信息。";
#pragma mark ---2.创建一个CT制造者---
    DWCoreTextFrameMaker * maker = [[DWCoreTextFrameMaker alloc] initWithString:content config:config];
#pragma mark ---制造者生成后，即已创建一个带有基本属性的富文本，在生成CT数据之前，仍可对富文本进行任何操作---
#pragma mark ---2.1添加局部属性---
    [maker addAttribute: NSFontAttributeName value:[UIFont fontWithName:@"Zapfino" size:40] range:NSMakeRange(0, 7)];
    [maker addAttribute:(NSString *)kCTForegroundColorAttributeName value:(id)[UIColor redColor].CGColor range:NSMakeRange(8, 10)];//这种方式可以改变颜色，nsforegroundcolorattributename更改失败
#pragma mark ---2.2创建图片信息字典---
    NSMutableDictionary * dic3 = [maker makePicDictionaryWithImageName:@"3.jpg" InsertLocation:25 imageSize:CGSizeMake(100, 200)];
#pragma mark ---2.3插入单个图片---
    [maker insertPicWithDictionary:dic3];
    NSMutableDictionary * dic2 = [maker makePicDictionaryWithImageName:@"2.jpg" InsertLocation:17 imageSize:CGSizeMake(200, 200)];
    NSMutableDictionary * dic = [maker makePicDictionaryWithImageName:@"1.jpg" InsertLocation:15 imageSize:CGSizeMake(100, 100)];
    NSMutableArray * arr = [NSMutableArray arrayWithObjects:dic,dic2, nil];
#pragma mark ---2.4以数组插入图片---
    [maker insertPicWithArrayOfDictionarys:arr];
#pragma mark ---3.生成CT数据---
    DWCoreTextData * data = [maker MakeCoreTextDataWithConfig:config];
#pragma mark ---4.绘制CTV---
    DWCoreTextView * CTV = [[DWCoreTextView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, data.height) data:data];
    CTV.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:CTV];
#pragma mark ---5.添加响应事件---
#pragma mark ---CTV生成以后则可以对其中的图片或字符串添加响应事件。给字符串添加事件的range要考虑到插入图片的影响。同一字符的事件响应优先级 图片 > 文字 ，后添加 > 先添加---
#pragma mark ---5.1给图片添加事件---
    [CTV addTarget:self Action:@selector(PicAction) ToImage:@"1.jpg"];
#pragma mark ---5.2给字符串添加事件---
    [CTV addTarget:self Action:@selector(StrAction) ToRangeOfStr:NSMakeRange(80, 10)];
    [CTV addTarget:self Action:@selector(strActionLater) ToRangeOfStr:NSMakeRange(85, 90)];
}
-(void)PicAction
{
    NSLog(@"您点击了指定图片");
}
-(void)StrAction
{
    NSLog(@"您点击了指定字符串");
}
-(void)strActionLater
{
    NSLog(@"这是指定字符串的第二次添加的响应事件");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
