//
//  DWCoreTextFrameMaker.m
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import "DWCoreTextFrameMaker.h"

@interface DWCoreTextFrameMaker ()
@property (strong ,nonatomic)NSMutableArray * arrImgName;
@property (strong ,nonatomic)NSMutableArray * arrLocationImgHasAdd;
@end
@implementation DWCoreTextFrameMaker
#pragma mark ---外界方法接口---
-(instancetype)initWithString:(NSString *)string
                       config:(DWCoreTextFrameMakerConfig *)config
{
    self = [super init];
    if (self) {
        self.attributeSTR = [[NSMutableAttributedString alloc] initWithString:string attributes:[self attributeWithConfig:config]];
    }
    return self;
}
-(void)addAttribute:(NSString *)attributeName
              value:(id)value
              range:(NSRange)range
{
    [self.attributeSTR addAttribute:attributeName value:value range:range];
}
-(void)insertPicWithDictionary:(NSMutableDictionary *)dic
{
    NSInteger location = [dic[@"location"] integerValue];//拿到字典中对应信息
    CGSize size = [dic[@"size"] CGSizeValue];
    NSString * imgName = dic[@"imgName"];
    CTRunDelegateCallbacks callBacks;//设置图片的回调
    memset(&callBacks, 0, sizeof(CTRunDelegateCallbacks));//memset将已开辟内存空间 callbacks 的首 n 个字节的值设为值 0, 相当于对CTRunDelegateCallbacks内存空间初始化
    callBacks.version = kCTRunDelegateVersion1;
    callBacks.getAscent = ascentCallBacks;
    callBacks.getDescent = descentCallBacks;
    callBacks.getWidth = widthCallBacks;
    CTRunDelegateRef delegate = CTRunDelegateCreate(& callBacks, (__bridge void *)[NSValue valueWithCGSize:size]);//设置CTRun代理，为期绑定回调方法及回调方法的参数，此处NSValue即为要绑定的参数，根据情况，此处参数随意设置
    unichar placeHolder = 0xFFFC;//创建占位符
    NSString * placeHolderStr = [NSString stringWithCharacters:&placeHolder length:1];
    NSMutableAttributedString * placeHolderAttrStr = [[NSMutableAttributedString alloc] initWithString:placeHolderStr];
    CFAttributedStringSetAttribute((CFMutableAttributedStringRef)placeHolderAttrStr, CFRangeMake(0, 1), kCTRunDelegateAttributeName, delegate);//为占位符绑定代理
    CFRelease(delegate);
    NSInteger offset = [self addToArrImgDicAndSortWithLocation:location];//计算当前添加的图片在所有添加已图片的位置，并插入对应位置的数组，返回校正偏移量
    [self.attributeSTR insertAttributedString:placeHolderAttrStr atIndex:location + offset];//将占位符添加到对应位置，应用校正偏移量对位置进行校正
    [self.arrImgName insertObject:imgName atIndex:offset];//将图片名称按正确顺序存入数组。
}
-(void)insertPicWithArrayOfDictionarys:(NSMutableArray *)arr
{
    for (NSMutableDictionary * dic in arr) {
        [self insertPicWithDictionary:dic];
    }
}
-(NSMutableDictionary *)makePicDictionaryWithImageName:(NSString *)imgName
                                        InsertLocation:(NSInteger)loacation
                                             imageSize:(CGSize)size
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:imgName forKey:@"imgName"];
    [dic setValue:[NSValue valueWithCGSize:size] forKey:@"size"];
    [dic setValue:[NSNumber numberWithInteger:loacation] forKey:@"location"];
    return dic;
}
-(DWCoreTextData *)MakeCoreTextDataWithConfig:(DWCoreTextFrameMakerConfig *)config
{
    CTFramesetterRef frameSetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)self.attributeSTR);//创建frame工厂
    CGSize restrictSize = CGSizeMake(config.width, CGFLOAT_MAX);//创建预估计尺寸
    CGSize suggestSize = CTFramesetterSuggestFrameSizeWithConstraints(frameSetter, CFRangeMake(0, 0), nil, restrictSize, nil);//根据工厂生成建议尺寸。宽度不变，高度自适应
    CGFloat height = suggestSize.height;
    CTFrameRef frame = [self createFrameWithFrameSetter:frameSetter config:config height:height];//创建一个自适应的CT绘制的frame
    DWCoreTextData * data = [[DWCoreTextData alloc] initWithHeight:height frame:frame STRLength:self.attributeSTR.length];//根据frame及自适应高度返回CT数据
    if (self.arrImgName.count) {//如果有添加图片，则进行图片绘制计算
        NSMutableArray * arrImgFrm = [self calculateImageRectWithFrame:frame];//按顺序返回所有图片的Frame
        NSMutableArray * arrImg = [NSMutableArray array];
        for (int i = 0; i < arrImgFrm.count; i++) {//将图片信息（文件名及frame）存入字典，在装入数组
            NSMutableDictionary * dic = [NSMutableDictionary dictionary];
            [dic setValue:self.arrImgName[i] forKey:@"imgName"];
            [dic setValue:arrImgFrm[i] forKey:@"imgFrm"];
            [arrImg addObject:dic];
        }
        data.arrImg = arrImg;//将装有所有图片信息的数组返回给CT数据
    }
    CFRelease(frame);
    CFRelease(frameSetter);
    return data;
}
#pragma mark ---工具方法---
///返回总绘制frame
-(CTFrameRef)createFrameWithFrameSetter:(CTFramesetterRef)frameSetter
                                 config:(DWCoreTextFrameMakerConfig *)config
                                 height:(CGFloat)height
{
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0, 0, config.width, height));//根据尺寸生成绘制路径
    CTFrameRef frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(0, 0), path, NULL);//根据frame工厂及绘制路径生成总绘制frame
    CFRelease(path);
    return frame;//计算frame
}


///返回所有图片的绘制frame数组
/*
 思路：
 根据当前绘制的frame找出所有CTRun（一个CTFrame由多个CTLine组成，
 一个CTLine又由多个CTRun组成，有共同属性的一部分字符为一个CTRun）
 ，拿出CTRun的属性，找到其代理。若代理为空或代理初始信息为空，则为
 非图片CTRun，跳过。否则根据对应行CTLine的原点，x轴偏移量，字符宽
 度、高度计算frame（y轴偏移量一定为0）。注意此frame为系统坐标。
 将查找到的所有frame放入数组中返回。
 */
-(NSMutableArray *)calculateImageRectWithFrame:(CTFrameRef)frame
{
    NSArray * arrLines = (NSArray *)CTFrameGetLines(frame);//根据frame获取需要绘制的线的数组
    NSInteger count = [arrLines count];//获取线的数量
    CGPoint points[count];//建立起点的数组（cgpoint类型为结构体，故用C语言的数组）
    CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), points);//获取起点
    NSMutableArray * arr = [NSMutableArray array];
    for (int i = 0; i < count; i ++) {//遍历线的数组
        CTLineRef line = (__bridge CTLineRef)arrLines[i];
        NSArray * arrGlyphRun = (NSArray *)CTLineGetGlyphRuns(line);//获取GlyphRun数组（GlyphRun：高效的字符绘制方案）
        for (int j = 0; j < arrGlyphRun.count; j ++) {//遍历CTRun数组
            CTRunRef run = (__bridge CTRunRef)arrGlyphRun[j];//获取CTRun
            NSDictionary * attributes = (NSDictionary *)CTRunGetAttributes(run);//获取CTRun的属性
            CTRunDelegateRef delegate = (__bridge CTRunDelegateRef)[attributes valueForKey:(id)kCTRunDelegateAttributeName];//获取代理
            if (delegate == nil) {//非空
                continue;
            }
            NSValue * Dvalue = CTRunDelegateGetRefCon(delegate);//取出代理初始化的对象（因为创建的时候为NSValue，所以用NSValue取）
            if (![Dvalue isKindOfClass:[NSValue class]]) {//判断其存在性
                continue;
            }
            CGPoint point = points[i];//获取一个起点
            CGFloat ascent;//获取上距
            CGFloat descent;//获取下距
            CGRect boundsRun;//创建一个frame
            boundsRun.size.width = CTRunGetTypographicBounds(run, CFRangeMake(0, 0), &ascent, &descent, NULL);//计算字符宽度的函数
#warning ---此处存疑---
            boundsRun.size.height = ascent + descent;//???为何+下距？descent是正是负，相关资料说是负的啊
            CGFloat xOffset = CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL);//获取x偏移量
            boundsRun.origin.x = point.x + xOffset;//point是行起点位置，加上每个字的偏移量得到每个字的x
#warning ---此处存疑---
            boundsRun.origin.y = point.y - descent;//???为何是-descent下距？原点左上or左下？与翻转画布有关么？
            CGPathRef path = CTFrameGetPath(frame);//获取绘制区域
            CGRect colRect = CGPathGetBoundingBox(path);//获取剪裁区域边框
            CGRect deleteBounds = CGRectOffset(boundsRun, colRect.origin.x, colRect.origin.y);//获取绘制区域
            NSValue * value = [NSValue valueWithCGRect:deleteBounds];
            [arr addObject:value];
        }
    }
    return arr;
}


///插入图片位置校正方法
/*
 保证图片插入时不因为在其前方位置已经有插入过的图片
 而导致位置插入不正确。同时保证图片名称数组中顺序即
 为插入的位置顺序，而不是先后顺序。防止先插入大角标
 位置，再插入小角标位置造成图片顺序错乱
 */
-(NSInteger)addToArrImgDicAndSortWithLocation:(NSInteger)location
{
    NSNumber * loc = [NSNumber numberWithInteger:location];
    if (self.arrLocationImgHasAdd.count == 0) {//如果数组是空的，直接添加位置，并返回0
        [self.arrLocationImgHasAdd addObject:loc];
        return 0;
    }
    [self.arrLocationImgHasAdd addObject:loc];//否则先插入，再排序
    [self.arrLocationImgHasAdd sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {//升序排序方法
        if ([obj1 integerValue] > [obj2 integerValue]) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        
        if ([obj1 integerValue] < [obj2 integerValue]) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    }];
    return [self.arrLocationImgHasAdd indexOfObject:loc];//返回本次插入图片的偏移量
}


///设置行间距及段落信息等
-(NSMutableDictionary *)attributeWithConfig:(DWCoreTextFrameMakerConfig *)config
{
    CTFontRef fontRef = CTFontCreateWithName((CFStringRef)config.fontFamily, config.fontSize, NULL);
    CGFloat lineSpacing = config.lineSpace;
    const CFIndex kNumberOfSettings = 3;
    CTParagraphStyleSetting theSettings[kNumberOfSettings] = {
        { kCTParagraphStyleSpecifierLineSpacingAdjustment, sizeof(CGFloat), &lineSpacing },
        { kCTParagraphStyleSpecifierMaximumLineSpacing, sizeof(CGFloat), &lineSpacing },
        { kCTParagraphStyleSpecifierMinimumLineSpacing, sizeof(CGFloat), &lineSpacing }
    };
    CTParagraphStyleRef theParagraphRef = CTParagraphStyleCreate(theSettings, kNumberOfSettings);
    NSMutableDictionary * attributes= [NSMutableDictionary dictionary];
    attributes[(id)kCTForegroundColorAttributeName] = (id)config.color;
    attributes[(id)kCTFontAttributeName] = (__bridge id)fontRef;
    attributes[(id)kCTParagraphStyleAttributeName] = (__bridge id)theParagraphRef;
    CFRelease(theParagraphRef);
    CFRelease(fontRef);
    return attributes;
}
#pragma mark ---CTRUN代理---
static CGFloat ascentCallBacks(void * ref)
{
    NSValue * value = (__bridge NSValue *)ref;///因为以NSValue初始化的代理，所以参数应为NSValue类型
    return [value CGSizeValue].height;
}
static CGFloat descentCallBacks(void * ref)
{
    return 0;
}
static CGFloat widthCallBacks(void * ref)
{
    NSValue * value = (__bridge NSValue *)ref;
    return [value CGSizeValue].width;
}
#pragma mark ---懒加载---
-(NSMutableArray *)arrLocationImgHasAdd
{
    if (!_arrLocationImgHasAdd) {
        _arrLocationImgHasAdd = [NSMutableArray array];
    }
    return _arrLocationImgHasAdd;
}
-(NSMutableArray *)arrImgName
{
    if (!_arrImgName) {
        _arrImgName = [NSMutableArray array];
    }
    return _arrImgName;
}
@end
