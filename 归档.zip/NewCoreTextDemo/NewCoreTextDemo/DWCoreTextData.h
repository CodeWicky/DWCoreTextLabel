//
//  DWCoreTextData.h
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//
/*
 CT数据
 存储coreText绘制需要的所有信息
 */
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
@interface DWCoreTextData : NSObject
@property (assign ,nonatomic)CGFloat height;
@property (assign ,nonatomic)CTFrameRef ctFrame;
@property (assign ,nonatomic)NSInteger length;
@property (strong ,nonatomic)NSMutableArray * arrImg;
///初始化CT数据
-(instancetype)initWithHeight:(CGFloat)height
                        frame:(CTFrameRef)frame
                    STRLength:(NSInteger)length;
@end
