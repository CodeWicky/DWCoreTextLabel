//
//  DWCoreTextView.h
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//


/*
 CTV
 
 coreText绘制所需要的View
 
 
 coreText与绘制原理
 
 首先coreText会根据绘制的frame将绘制区域分成CTLine。每一行即为一个CTLine。
 然后再将一个CTLine分成若干个CTRun。每个CTRun中是包含相同属性的一段富文本。
 然后逐个绘制每个CTRun。
 
 
 
 coreText的基本思路
 
 在View上绘制一个富文本字符串。
 此字符串可以有各种属性。
 若字符串的代理中有图片属性，则该出显示图片。
 故在字符串中添加一个空白的字符串作为图片占位符，设置代理绑定相关属性即可在富文本中插入图片
 实现图文混排
 
 
 点击事件的实现
 
 通过touchBegin方法获取点击的屏幕坐标，转换为系统坐标后，遍历富文本字符串的每一个字符，获取每一个字符的frame，判断点是否在frame里来实现点击事件的响应
 */
#import <UIKit/UIKit.h>
#import "DWCoreTextFrameMaker.h"
@interface DWCoreTextView : UIView
@property (strong ,nonatomic)DWCoreTextData * data;
///根据frame及CT数据初始化CTV
-(instancetype)initWithFrame:(CGRect)frame data:(DWCoreTextData *)data;
///给图片添加响应方法
-(void)addTarget:(UIViewController *)VC Action:(SEL)action ToImage:(NSString *)imageName;
///给一段范围的字符串添加响应方法
-(void)addTarget:(UIViewController *)VC Action:(SEL)action ToRangeOfStr:(NSRange)range;
@end
