//
//  DWCoreTextFrameMakerConfig.m
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import "DWCoreTextFrameMakerConfig.h"

@implementation DWCoreTextFrameMakerConfig
-(instancetype)initWithWidth:(CGFloat)width fontSize:(CGFloat)fontSize lineSpace:(CGFloat)lineSpace color:(UIColor *)color fontFamily:(NSString *)fontFamily
{
    self = [super init];
    if (self) {
        self.width = width;
        self.fontSize = fontSize;
        self.lineSpace = lineSpace;
        self.color = color;
        self.fontFamily = fontFamily;
    }
    return self;
}
@end
