//
//  DWCoreTextView.m
//  NewCoreTextDemo
//
//  Created by Wicky on 16/4/25.
//  Copyright © 2016年 Wicky. All rights reserved.
//

#import "DWCoreTextView.h"

@interface DWCoreTextView ()
@property (strong ,nonatomic)NSMutableArray * arrImgActions;
@property (strong ,nonatomic)NSMutableArray * arrStrActions;
@end
@implementation DWCoreTextView
#pragma mark ---外界方法接口---
-(instancetype)initWithFrame:(CGRect)frame data:(DWCoreTextData *)data
{
    self = [super initWithFrame:frame];
    if (self) {
        self.data = data;
    }
    return self;
}
-(void)addTarget:(UIViewController *)VC Action:(SEL)action ToImage:(NSString *)imageName
{
    NSString * actionStr = NSStringFromSelector(action);
    NSDictionary * dic = @{@"target":VC,@"action":actionStr,@"imgName":imageName};
    [self.arrImgActions insertObject:dic atIndex:0];
}
-(void)addTarget:(UIViewController *)VC Action:(SEL)action ToRangeOfStr:(NSRange)range
{
    NSString * actionStr = NSStringFromSelector(action);
    NSValue * rangeValue = [NSValue valueWithRange:range];
    NSDictionary * dic = @{@"target":VC,@"action":actionStr,@"range":rangeValue};
    [self.arrStrActions insertObject:dic atIndex:0];
}

#pragma mark ---工具方法---
///绘制方法
-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);//坐标系转换
    CGContextTranslateCTM(context, 0, self.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    if (self.data) {
        CTFrameDraw(self.data.ctFrame, context);//绘制富文本
        if (self.data.arrImg.count) {//如果有图片，绘制图片
            for (NSMutableDictionary * dic in self.data.arrImg) {
                CGRect imgFrm = [dic[@"imgFrm"] CGRectValue];
                NSString * imgName = dic[@"imgName"];
                CGContextDrawImage(context, imgFrm, [UIImage imageNamed:imgName].CGImage);
            }
        }
    }
}
///点击方法
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    CGPoint location = [self systemPointFromScreenPoint:[touch locationInView:self]];//获取点击位置的系统坐标
    if ([self checkIsClickOnImgWithPoint:location]) {//检查是否点击在图片上，如果在，优先响应图片事件
        return;
    }
    [self ClickOnStrWithPoint:location];//响应字符串事件
}
///图片点击检查
/*
 遍历图片frame的数组与点击位置比较，如果在
 范围内则响应的数组中取出对应响应并执行，返
 回yes，否则返回no
 */
-(BOOL)checkIsClickOnImgWithPoint:(CGPoint)location
{
    for (NSMutableDictionary * dic in self.data.arrImg) {
        CGRect imgFrm = [dic[@"imgFrm"] CGRectValue];
        if ([self isFrame:imgFrm containsPoint:location]) {
            NSString * imageName = dic[@"imgName"];
            for (NSDictionary * dicTemp in self.arrImgActions) {
                if ([dicTemp[@"imgName"] isEqualToString:imageName]) {
                    SEL action = NSSelectorFromString(dicTemp[@"action"]);
                    UIViewController * VC = dicTemp[@"target"];
                    [VC performSelector:action];
                    return YES;
                }
            }
        }
    }
    return NO;
}
///字符串点击检查
/*
 实际上接受所有非图片的点击事件，将字符串的每个
 字符取出与点击位置比较，若在范围内则点击到文字
 ，进而检测对应的文字是否响应事件，若存在响应
 */
-(void)ClickOnStrWithPoint:(CGPoint)location
{
    NSArray * lines = (NSArray *)CTFrameGetLines(self.data.ctFrame);//获取所有CTLine
    CFRange ranges[lines.count];//初始化范围数组
    CGPoint origins[lines.count];//初始化原点数组
    CTFrameGetLineOrigins(self.data.ctFrame, CFRangeMake(0, 0), origins);//获取所有CTLine的原点
    for (int i = 0; i < lines.count; i ++) {
        CTLineRef line = (__bridge CTLineRef)lines[i];
        CFRange range = CTLineGetStringRange(line);
        ranges[i] = range;
    }//获取所有CTLine的Range
    for (int i = 0; i < self.data.length; i ++) {//逐字检查
        long maxLoc;
        int lineNum;
        for (int j = 0; j < lines.count; j ++) {//获取对应字符所在CTLine的index
            CFRange range = ranges[j];
            maxLoc = range.location + range.length - 1;
            if (i <= maxLoc) {
                lineNum = j;
                break;
            }
        }
        CTLineRef line = (__bridge CTLineRef)lines[lineNum];//取到字符对应的CTLine
        CGPoint origin = origins[lineNum];
        CGRect CTRunFrame = [self frameForCTRunWithIndex:i CTLine:line origin:origin];//计算对应字符的frame
        CGPathRef path = CTFrameGetPath(self.data.ctFrame);//获取绘制区域
        CGRect colRect = CGPathGetBoundingBox(path);//获取剪裁区域边框
        CGRect CTRunFrameAdjusted = CGRectOffset(CTRunFrame, colRect.origin.x, colRect.origin.y);//校正CTFrame的偏移后转换成屏幕坐标
        if ([self isFrame:CTRunFrameAdjusted containsPoint:location]) {//如果点击位置在字符范围内，响应时间，跳出循环
            if ([self hasActionForStrAtIndex:i]) {//检测对应字符是否有响应事件，如果有，则响应
                return;
            }
            NSLog(@"您点击到了第 %d 个字符，位于第 %d 行，然而他没有响应事件。",i,lineNum + 1);//点击到文字，然而没有响应的处理。可以做其他处理
            return;
        }
    }
    NSLog(@"您没有点击到文字");//没有点击到文字，可以做其他处理
}
///范围检测
/*
 范围内返回yes，否则返回no
 */
-(BOOL)isIndex:(NSInteger)index inRange:(NSRange)range
{
    if ((index <= range.location + range.length - 1) && (index >= range.location)) {
        return YES;
    }
    return NO;
}
///字符响应检测
/*
 检测索引对应字符是否包含响应时间，如果有，则响应并返回yes，否则返回no
 */
-(BOOL)hasActionForStrAtIndex:(NSInteger)index
{
    for (NSDictionary * dic in self.arrStrActions) {
        NSRange range = [dic[@"range"] rangeValue];
        if ([self isIndex:index inRange:range]) {
            SEL action = NSSelectorFromString(dic[@"action"]);
            UIViewController * VC = dic[@"target"];
            [VC performSelector:action];
            return YES;
        }
    }
    return NO;
}
///坐标转换
/*
 将屏幕坐标转换为系统坐标
 */
-(CGPoint)systemPointFromScreenPoint:(CGPoint)origin
{
    return CGPointMake(origin.x, self.bounds.size.height - origin.y);
}
///点包含检测
-(BOOL)isFrame:(CGRect)frame containsPoint:(CGPoint)point
{
    return CGRectContainsPoint(frame, point);
}
///字符frame计算
/*
 返回索引字符的frame
 
 index：索引
 line：索引字符所在CTLine
 origin：line的起点
*/
-(CGRect)frameForCTRunWithIndex:(NSInteger)index
                         CTLine:(CTLineRef)line
                         origin:(CGPoint)origin
{
    CGFloat offsetX = CTLineGetOffsetForStringIndex(line, index, NULL);//获取字符起点相对于CTLine的原点的偏移量
    CGFloat offsexX2 = CTLineGetOffsetForStringIndex(line, index + 1, NULL);//获取下一个字符的偏移量，两者之间即为字符X范围
    offsetX += origin.x;
    offsexX2 += origin.x;//坐标转换，将点的CTLine坐标转换至系统坐标
    CGFloat offsetY = origin.y;//取到CTLine的起点Y
    CGFloat lineAscent;//初始化上下边距的变量
    CGFloat lineDescent;
    NSArray * runs = (__bridge NSArray *)CTLineGetGlyphRuns(line);//获取所有CTRun
    CTRunRef runCurrent;
    for (int k = 0; k < runs.count; k ++) {//获取当前点击的CTRun
        CTRunRef run = (__bridge CTRunRef)runs[k];
        CFRange range = CTRunGetStringRange(run);
        NSRange rangeOC = NSMakeRange(range.location, range.length);
        if ([self isIndex:index inRange:rangeOC]) {
            runCurrent = run;
            break;
        }
    }
    CTRunGetTypographicBounds(runCurrent, CFRangeMake(0, 0), &lineAscent, &lineDescent, NULL);//计算当前点击的CTRun高度
    CGFloat height = lineAscent + lineDescent;
    return CGRectMake(offsetX, offsetY, offsexX2 - offsetX, height);//返回一个字符的Frame
}

#pragma mark ---懒加载---
-(NSMutableArray *)arrImgActions
{
    if (!_arrImgActions) {
        _arrImgActions = [NSMutableArray array];
    }
    return _arrImgActions;
}
-(NSMutableArray *)arrStrActions
{
    if (!_arrStrActions) {
        _arrStrActions = [NSMutableArray array];
    }
    return _arrStrActions;
}
@end
